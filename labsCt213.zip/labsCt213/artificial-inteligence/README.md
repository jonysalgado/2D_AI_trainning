# artificial-inteligence
atividades ministradas no curso de CT213(Inteligência artificial aplicada a robótica móvel)
